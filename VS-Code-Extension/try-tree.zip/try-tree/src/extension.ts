import * as vscode from 'vscode';
import * as axios from 'axios';
import * as xmlParser from 'fast-xml-parser';

export function activate(context: vscode.ExtensionContext) {
	
	console.log('Congratulations, your extension "try-tree" is now active!');

	let disposable = vscode.commands.registerCommand('try-tree.searchPapers', firstWork);

	context.subscriptions.push(disposable);
	let disposable_2 = vscode.commands.registerCommand('try-tree.searchDoi', doiWork);

	context.subscriptions.push(disposable_2);
	let disposable_3 = vscode.commands.registerCommand('try-tree.contextFunc', function(){console.log("Context Function: TBA");});

	context.subscriptions.push(disposable_3);

	let disposable_4 = vscode.commands.registerCommand('try-tree.setNoOfHits', set_no_of_results);

	context.subscriptions.push(disposable_4);
	
	// get_result_post("uires changes. The effects of database schema change upon applications is currently often estimated manually by application experts [2]. Assessing these effects manually is both fragile and difficult =-=[17]-=-, and can be frequently incorrect [20]. Moreover impact analysis from code inspections can be prohibitively expensive [22]. Therefore, in this paper we address the problem of assessing the effects of   shall conduct further evaluation of the usefulness, accuracy and scalability of this approach in future work. 6. RELATED WORK There is a great deal of work related to software change impact analysis =-=[3, 23, 17]-=-. However, we are only aware of one similar project that focussed on impact analysis of database schemas [16]. This earlier work focuses on object-oriented databases whereas we consider relational dat");
}

async function set_no_of_results(){
	// vscode.window.showInputBox()
	await vscode.window.showQuickPick(
		[
			{ label: '5', description: 'Papers' },
			{ label: '10', description: 'Papers' },
			{ label: '15', description: 'Papers' },
			{ label: '20', description: 'Papers' },
			{ label: 'Enter specific number', description: 'User Input' }
		],
		{ placeHolder: 'Select the no of results to show when searching for papers.' }
		).then(async response => {
			if(response!=undefined){
				if(response.description=='User Input'){
					await vscode.window.showInputBox({prompt: 'No of results to show when searching for papers ',placeHolder: 'Enter a positive integer' }
					).then(response => {
						if(response!=undefined && response!=""){
							set_no_post(response)
						}
					})
				}else{
					set_no_post(response.label);
				}
			}
		})
}

async function set_no_post(text: String){
	var data;
	var ax = axios.default;
	var res = await ax.post('http://localhost:5000/getResults', {setMaxResult: text}
		).then(response => {
			if(response.data=='Updated the value'){
				vscode.window.showInformationMessage('Update the Value of Max Results Shown')
			}else if(response.data=='Invalid value'){
				vscode.window.showErrorMessage('Invalid Entry')
			}
		}
		).catch(error => {
			vscode.window.showErrorMessage('Error: Connection failed to Server', );
			console.log("Error: POST Request failed to Server");
			console.error(error)
		}
		)
}

function doiWork(){
	// vscode.window.showInformationMessage('Hello World from Try Tree(Other function)!');
	var editor = vscode.window.activeTextEditor;
	if (!editor) {
		console.log("No open text editor");
		vscode.window.showErrorMessage("No Editor Opened");
	}else{
		var text = editor.document.getText(editor.selection);
		if(text.length<=0){
			console.log("No Text Selected");
			vscode.window.showErrorMessage("No Text Selected");		
		}else{
			get_metaonly_result_post(text)
			// var doi = await  vscode.window.showQuickPick(cids, {matchOnDetail: true});
		}
	}
}

function firstWork(){
	// vscode.window.showInformationMessage('Hello World from Try Tree(Other function)!');
	var editor = vscode.window.activeTextEditor;
	if (!editor) {
		console.log("No open text editor");
		vscode.window.showErrorMessage("No Editor Opened");
	}else{
		var text = editor.document.getText(editor.selection);
		if(text.length<=0){
			console.log("No Text Selected");
			vscode.window.showErrorMessage("No Text Selected");		
		}else{
			get_result_post(text)
			// var doi = await  vscode.window.showQuickPick(cids, {matchOnDetail: true});
		}
	}
}

async function get_result_post(text: String){
	var data;
	var ax = axios.default;
	var res = await ax.post('http://localhost:5000/getResults', {context: text}
		).then(response => {
			// console.log(`statusCode: ${response.statusCode}`)
			data = response.data
			if(data=="All Stop Words. No Match Found"){
				vscode.window.showWarningMessage('Each word is a stopword. No Results Found');
			}else if(data=="No Hits. No Match Found"){
				vscode.window.showWarningMessage('No Results Found');
			}else{
				// rankedlist = xmlParser.parse(data).result.item
				console.log("Got the reply and showed result");
				vscode.window.registerTreeDataProvider(
					'exampleView',
					new PaperListProvider(data)
				  );
				vscode.window.createTreeView('exampleView', {
					treeDataProvider: new PaperListProvider(data)
				  });
				// vscode.window.registerTreeDataProvider('exampleView', new TreeDataProvider());
			}
			console.log("Done");
		}
		).catch(error => {
			vscode.window.showErrorMessage('Error: Connection failed to Server', );
			console.log("Error: POST Request failed to Server");
			console.error(error)
		}
		)
}

async function get_metaonly_result_post(text: String){
	var data;
	var ax = axios.default;
	var res = await ax.post('http://localhost:5000/getResults', {meta: text}
		).then(response => {
			// console.log(`statusCode: ${response.statusCode}`)
			data = response.data
			if(data=="All Stop Words. No Match Found"){
				vscode.window.showWarningMessage('Each word is a stopword. No Results Found');
			}else if(data=="No Hits. No Match Found"){
				vscode.window.showWarningMessage('No Results Found');
			}else{
				// rankedlist = xmlParser.parse(data).result.item
				console.log("Got the reply and showed result");
				vscode.window.registerTreeDataProvider(
					'exampleView',
					new PaperListProvider(data)
				  );
				vscode.window.createTreeView('exampleView', {
					treeDataProvider: new PaperListProvider(data)
				  });
				// vscode.window.registerTreeDataProvider('exampleView', new TreeDataProvider());
			}
			console.log("Done");
		}
		).catch(error => {
			vscode.window.showErrorMessage('Error: Connection failed to Server', );
			console.log("Error: POST Request failed to Server");
			console.error(error)
		}
		)
}


export class PaperListProvider implements vscode.TreeDataProvider<SinglePaper>{
	constructor(private results: string){}
	getTreeItem(element: SinglePaper): vscode.TreeItem{
		return element;
	}
	getChildren(element?: SinglePaper) : Thenable<SinglePaper[]> {
		var listPaper: SinglePaper[] = [];
		if(element){
			// console.log("Called this " + element);
			if(element.contextValue == "CID"){
				// console.log("child obj" + element.child);
				// console.log("doino" + element.child.doino);
				// console.log("length" + element.child.doi.length)

				if((element.child).doi.length>1){
					console.log("CAlled this");

					for(var val1 of element.child.doi){
						console.log(val1 + "is this");
						
						if(val1.meta=='null'){
							listPaper.push(new SinglePaper(val1.doino.toString(), vscode.TreeItemCollapsibleState.None, "DOI", val1.meta))
						}else{
							listPaper.push(new SinglePaper(val1.doino.toString(), vscode.TreeItemCollapsibleState.Collapsed, "DOI", val1.meta))
						}
					}
				}else{
					if(element.child.doi.meta=='null'){
						listPaper.push(new SinglePaper(element.child.doi.doino.toString(), vscode.TreeItemCollapsibleState.None, "DOI", element.child.doi.meta))
					}else{
						listPaper.push(new SinglePaper(element.child.doi.doino.toString(), vscode.TreeItemCollapsibleState.Collapsed, "DOI", element.child.doi.meta))
					}
				}
			}else if(element.contextValue == "DOI"){
				listPaper.push(new SinglePaper(element.child.title.toString(), vscode.TreeItemCollapsibleState.None, "Title"));
				listPaper.push(new SinglePaper(element.child.author.toString(), vscode.TreeItemCollapsibleState.None, "Author(s)"));
				listPaper.push(new SinglePaper(element.child.venue.toString(), vscode.TreeItemCollapsibleState.None, "Venue"));
				listPaper.push(new SinglePaper(element.child.year.toString(), vscode.TreeItemCollapsibleState.None, "Year"));
				listPaper.push(new SinglePaper(element.child.key.toString(), vscode.TreeItemCollapsibleState.None, "Key"));
				listPaper.push(new SinglePaper(element.child.abstract.toString(), vscode.TreeItemCollapsibleState.None, "Abstract"));

			}
		// No element : Start from cids
		}else{
			var cids = xmlParser.parse(this.results).result.item.cid
			if(cids.length>0){
				for(var val of cids){
					// console.log("ITEM: "+val.cid + val.doi);
					if(val.doi=='null'){
						listPaper.push(new SinglePaper(val.cidno.toString(), vscode.TreeItemCollapsibleState.None, "CID", val))
					}else{
						listPaper.push(new SinglePaper(val.cidno.toString(), vscode.TreeItemCollapsibleState.Collapsed, "CID", val))
					}
				}
			}
		}
		return Promise.resolve(listPaper);
	}

}


//https://code.visualstudio.com/api/references/vscode-api#TreeItem
//Look at other properties like context etc.
class SinglePaper extends vscode.TreeItem{
	constructor(public readonly label: string, public readonly collapsibleState: vscode.TreeItemCollapsibleState, 
				public readonly contextValue: string, public readonly child?: any){
		super(label, collapsibleState);
		
		this.tooltip = label
		this.contextValue = contextValue
		// this.doi = doi
		this.child = child;
		this.description=label;
		this.label = contextValue
		
	}
}


// this method is called when your extension is deactivated
export function deactivate() {}


// var sampleRes = xmlParser.parse("<result><item><cid>904295</cid><doi>null</doi></item><item><cid>13475</cid><doi>null</doi></item><item><cid>904297</cid><doi>null</doi></item><item><cid>184324</cid><doi>[10.1.1.12.748, 10.1.1.18.3991, 10.1.1.20.54, 10.1.1.331.4491, 10.1.1.9.4980]</doi></item><item><cid>83883</cid><doi>[10.1.1.330.3835, 10.1.1.39.7056, 10.1.1.63.8961]</doi></item></result>")
