package tryServer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CidToDoi {
	Map<String, List<String>> doiToCid;
	String CLUSTERID_DOI;
	
	public CidToDoi(String clusterid_doi_path) throws IOException {
		CLUSTERID_DOI = clusterid_doi_path;
		createClusterIdFromDoi();
	}
	
	public void createClusterIdFromDoi() throws IOException {
    	String doi = "";
		String clusterId = "";
		doiToCid = new HashMap<String, List<String>>();
		
		BufferedReader br = new BufferedReader(new FileReader(new File(CLUSTERID_DOI)));
		String line;
		List<String> dois = new ArrayList<String>();
		while((line=br.readLine())!=null) {
			if(line.charAt(line.length()-1)==':') {
				doiToCid.put(clusterId, dois);
				clusterId = line.substring(0, line.length()-1);
				dois = new ArrayList<String>();
			}
			else {
				doi = line.trim();
				dois.add(doi);
			}			
		}
    }
	
	public Map<String, List<String>> getMap() {
		return doiToCid;
	}
}