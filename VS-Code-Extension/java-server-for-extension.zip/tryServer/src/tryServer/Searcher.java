package tryServer;

import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.search.similarities.LMJelinekMercerSimilarity;
import org.apache.lucene.store.FSDirectory;

public class Searcher {

	Integer TOTAL_HITS = 3000000;
	
	IndexReader reader;
	IndexSearcher searcher;
	myAnalyzer myanalyzer;
	Analyzer analyzer;

    MultiFieldQueryParser mFQueryParser;
    
    ScoreDoc[] hits;
    TopDocs topDocs;
    TopScoreDocCollector collector;
    
    Map<String, List<String>> cidToDoi;
    
	
	public Searcher(String INDEX_PATH, String STOPWORDS_FILE, String CID_DOI_FILE) {
		
		try {
			cidToDoi = new CidToDoi(CID_DOI_FILE).getMap();
			reader = DirectoryReader.open(FSDirectory.open(Paths.get(INDEX_PATH)));
			myanalyzer = new myAnalyzer(STOPWORDS_FILE);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
        
        
	}
	
	public String getResults(String context, String XML_PREFIX, Integer NO_OF_HITS) throws IOException, ParseException {
//		Date initTime = new Date();
		searcher = new IndexSearcher(reader);
	    
	    searcher.setSimilarity(new LMJelinekMercerSimilarity((float) 0.5));
	    
    	analyzer = myanalyzer.analyzer;
    	
    	String []fields = new String[]{"context"};
        
        mFQueryParser = new MultiFieldQueryParser(fields, new StandardAnalyzer());
        collector = TopScoreDocCollector.create(NO_OF_HITS, TOTAL_HITS);
		hits = null;
        topDocs = null;

		String query_str = getBOWQuery(analyzer, context).replace(":", " ");
//		System.out.println("Q: " + query_str);
		if(query_str.equals("")) {
        	return new String("All Stop Words. No Match Found");
        }
		
        searcher.search(mFQueryParser.parse(query_str), collector);
		topDocs = collector.topDocs();
        hits = topDocs.scoreDocs;
        
        if(hits.length==0) {
        	return new String("No Hits. No Match Found");
        }
        
        StringBuffer buff = new StringBuffer();
        buff.append("<result><item>");
//        System.out.println("Got " + hits.length + " hits");
        for (int i = 0; i < hits.length; ++i) {
        	buff.append("<cid><cidno>");
        	String cid = searcher.doc(hits[i].doc).get("doi");
        	buff.append(cid + "</cidno>");
//        	System.out.println("CID: " + cid);
    		List<String> dois = cidToDoi.get(cid);
//    		System.out.println(dois);
    		if(dois==null) {
//            	System.out.println("DOI: " + "null");
    			buff.append("<doi>null</doi>");
    		}else {
    			for(String doi : dois) {
//    				System.out.println("DOI: " + doi);
    				String meta = new ReadXml().getDetails(XML_PREFIX + doi + ".xml");
//    				System.out.println("meta: " + meta);
    				buff.append("<doi><doino>"+doi+"</doino><meta>"+meta+"</meta></doi>");
    			}
    		}
    		buff.append("</cid>");
        }
        buff.append("</item></result>");
//        System.out.println("buff: " + buff.toString());
		return buff.toString();
	}   
	
	public String getResultsWithMetaData(String context, String XML_PREFIX,  Integer NO_OF_HITS) throws IOException, ParseException {
//		Date initTime = new Date();
		searcher = new IndexSearcher(reader);
	    
	    searcher.setSimilarity(new LMJelinekMercerSimilarity((float) 0.5));
	    
    	analyzer = myanalyzer.analyzer;
    	
    	String []fields = new String[]{"context"};
        
        mFQueryParser = new MultiFieldQueryParser(fields, new StandardAnalyzer());
        // Get 10x and hope we get required Number of metadata DOI
        collector = TopScoreDocCollector.create(NO_OF_HITS * 10, TOTAL_HITS);
		hits = null;
        topDocs = null;

		String query_str = getBOWQuery(analyzer, context).replace(":", " ");
//		System.out.println("Q: " + query_str);
		if(query_str.equals("")) {
        	return new String("All Stop Words. No Match Found");
        }
		
        searcher.search(mFQueryParser.parse(query_str), collector);
		topDocs = collector.topDocs();
        hits = topDocs.scoreDocs;
        
        if(hits.length==0) {
        	return new String("No Hits. No Match Found");
        }
        
        StringBuffer buff = new StringBuffer();
        buff.append("<result><item>");

        Integer count = 0;
        for (int i = 0; i < hits.length && count<NO_OF_HITS; ++i) {
        	String cid = searcher.doc(hits[i].doc).get("doi");
    		List<String> dois = cidToDoi.get(cid);
    		if(dois!=null) {
    		
    			for(String doi : dois) {
    				String meta = new ReadXml().getDetails(XML_PREFIX + doi + ".xml");
    				if(!(meta.equals("null"))) {
    					count++;
    					buff.append("<cid><cidno>").append(cid + "</cidno><doi><doino>"+doi+"</doino><meta>"+meta+"</meta></doi></cid>");
    					break;
    				}
    			}
    		}
        }
        buff.append("</item></result>");
//        System.out.println("buff: " + buff.toString());
		return buff.toString();
	}   
	
	public String getBOWQuery(Analyzer analyzer, String context) throws IOException {

		StringBuffer buff = new StringBuffer(); 
		context = context.replace("\n", " ").replaceAll("\\p{Punct}", "").replaceAll(" +[a-zA-Z\\d] +", " ");
		System.out.println("Cleaned: " + context);
		
		TokenStream stream = analyzer.tokenStream("field_context", new StringReader(context));
		CharTermAttribute termAtt = stream.addAttribute(CharTermAttribute.class);
		stream.reset();
		while (stream.incrementToken()) {
//			System.out.println("Term: " + termAtt.toString());
			buff.append(termAtt.toString().toLowerCase()).append(" ");
		}
		stream.end();
		stream.close();
//		System.out.println("Buff: " + buff.toString());
		String q = "";
		for (String term : buff.toString().split("\\s+")) {
		    q = q + new TermQuery(new Term(term)).toString();
		}
		return q;
	}
}