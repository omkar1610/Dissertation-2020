package tryServer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadXml {
	public ReadXml() {
		
	}
	public String getDetails(String filePath) throws IOException {
		FileReader fr;
		try {
			fr = new FileReader(new File(filePath));
		} catch (FileNotFoundException e) {
			return new String("null");
		}
		
		BufferedReader br=new BufferedReader(fr);  
		StringBuffer sb=new StringBuffer();  
		String line;
		Boolean isMeta = false;
		while((line=br.readLine())!=null)  {
			if(line.startsWith("<citations>")) {
				break;
			}
			if(isMeta==true || line.startsWith("<title>")) {
				isMeta = true;
				sb.append(line);
			}
		}  
		fr.close();  
//		System.out.println("Contents of File: ");  
//		System.out.println(sb.toString());  
		
		return sb.toString();
	}  
	
}
