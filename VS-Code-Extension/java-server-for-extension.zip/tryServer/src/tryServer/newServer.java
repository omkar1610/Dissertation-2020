package tryServer;

import java.io.*;
import java.net.InetSocketAddress;

import org.apache.lucene.queryparser.classic.ParseException;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

public class newServer {
	static Searcher searcher;
	static String XML_PREFIX = "../citeseerx-partial-papers/";
	static Integer NO_OF_HITS = 5;
	public static void main(String[] args) throws IOException {
		String RD_FILE = "/Users/omkar.a/eclipse-workspace/required_server_files/reference_index_rd_file/";
		String STOPWORDS = "/Users/omkar.a/eclipse-workspace/required_server_files/stopwords";
		String CID_DOI = "/Users/omkar.a/eclipse-workspace/required_server_files/clusters.txt";
		
		Searcher searcher = new Searcher(RD_FILE, STOPWORDS, CID_DOI);
		
		HttpServer server = HttpServer.create(new InetSocketAddress("localhost", 5000), 0);
		
		server.createContext("/getResults", exchange -> {
			try {
				handleGetResult(exchange, searcher);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		});
//		server.createContext("/getXmlMapping", newServer::handleRequest);
		
		server.start();
		System.out.println(" Server started on port 5000");
	}

	private static void handleGetResult(HttpExchange exchange, Searcher searcher) throws IOException, ParseException {
//		System.out.println(exchange);
		
		String method = exchange.getRequestMethod().toString();
//		String uri = exchange.getRequestURI().toString();
		
		String response = "";
		if(method.equals("POST")) {
			System.out.println("Got a Post request");
			StringBuilder sb = new StringBuilder();
            InputStream ios = exchange.getRequestBody();
            int i;
            while ((i = ios.read()) != -1) {
                sb.append((char) i);
            }
            String t = sb.toString();

            String keyWord = t.split(":", 2)[0];
            
            if(keyWord.equals("{\"context\"")) {
	            t = t.split(":", 2)[1];
	            String query_context = t.substring(1, t.length()-2);
	            
	            System.out.println("Received: " + query_context);
	            response = searcher.getResults(query_context, XML_PREFIX, NO_OF_HITS);
	            
            }else if(keyWord.equals("{\"meta\"")) {
            	t = t.split(":", 2)[1];
	            String query_context = t.substring(1, t.length()-2);
	            
	            System.out.println("Received: " + query_context);
	            response = searcher.getResultsWithMetaData(query_context, XML_PREFIX, NO_OF_HITS);
	            
            }else if(keyWord.equals("{\"setMaxResult\"")) {
            	System.out.println(t);
            	t = t.split(":", 2)[1];
            	t = t.substring(1, t.length()-2);
//            	System.out.println("here" + t);
            	try {
					Integer tmp = Integer.parseInt(t);
					if(tmp>0) {
						NO_OF_HITS = tmp;
						response = "Updated the value";
					}else {
						response =  "Invalid value";
					}
				} catch (Exception e) {
					response = "Invalid value";
				}
            }
            System.out.println("Sent: " + response);
		}

		Headers responseHeaders = exchange.getResponseHeaders();
		responseHeaders.set("Content-Type", "xml");
		exchange.sendResponseHeaders(200, response.getBytes().length);//response code and length
		OutputStream os = exchange.getResponseBody();
		os.write(response.getBytes());
		os.close();
	}
}
















//ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor)Executors.newFixedThreadPool(10);
//server.setExecutor(threadPoolExecutor);


